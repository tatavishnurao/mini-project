import { Sparkles } from 'lucide-react';
import type { Job } from '../App';

interface JobCardProps {
  job: Job;
  isDark: boolean;
}

export function JobCard({ job, isDark }: JobCardProps) {
  return (
    <div className={`${isDark ? 'bg-[#1a1d29] border-gray-800' : 'bg-white border-gray-200'} rounded-xl p-6 border hover:border-purple-500/50 transition-all shadow-lg`}>
      {/* Name and Email */}
      <div className="mb-4">
        <h3 className={`text-xl font-semibold mb-1 ${isDark ? 'text-white' : 'text-gray-900'}`}>{job.name}</h3>
        <p className="text-gray-400 text-sm">{job.email}</p>
        <p className={`${isDark ? 'text-white' : 'text-gray-900'} font-semibold mt-2`}>CGPA: {job.cgpa}</p>
      </div>

      {/* Skills */}
      <div className="flex flex-wrap gap-2 mb-6">
        {job.skills.map((skill, index) => (
          <span
            key={index}
            className={`px-3 py-1 ${isDark ? 'bg-purple-900/40 text-purple-300 border-purple-700/50' : 'bg-purple-100 text-purple-700 border-purple-300'} rounded-full text-sm border`}
          >
            {skill}
          </span>
        ))}
      </div>

      {/* Analyze Button */}
      <button className="w-full py-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg font-semibold hover:from-purple-600 hover:to-pink-600 transition-all flex items-center justify-center gap-2 shadow-lg text-white">
        Analyze Match
        <Sparkles size={16} />
      </button>
    </div>
  );
}